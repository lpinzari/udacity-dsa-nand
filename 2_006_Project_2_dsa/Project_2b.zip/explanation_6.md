# Union and Intersection of Two linked lists

Task: You will take in two linked lists and return a linked list that is composed of either the union or intersection, respectively.

For the **union** and **intersection** problems, the approach has been to use ***three iterators*** to loop over the three linked lists and auxiliaries ***Python's sets*** data structure to keep track of the elements added in the list.

The basic idea is to iterate concurrently over the two inputs linked list and building the new linked list by checking the presence of each element in the union and intersection set.


## Time and Space Complexity

Let **s** and **t** be the length of the first and second list, respectively. (i.e **s = len(llist_1) ;  t = len(llist_2)**.

In terms of **Time Complexity**, the number of iterations are exactly equal to the dimension of the biggest input list. It follows that this algorithm is **Theta(max(s,t))** (i.e worst, average and best case are identical).

- `union(llist_1, llist_2)`: **O( max(s,t) )**
- `intersection(llist_1, llist_2)`: **O( max(s,t) )**

In terms of **Space Complexity**, both functions require **O(s + t)**; in the worst case when all elements in the lists are different.
