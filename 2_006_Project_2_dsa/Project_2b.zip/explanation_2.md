# Finding Files

The ***recursive process*** is based on the visit of the *sub-directories* (*folders*) in the given directory. For each *sub-directory* we keep the files that match the desired *extension* and we keep on going deeper on the *sub-directory* structure by calling the subsequent calls to the function. Note that the in initial argument (the root) must be a directory of the File System (precondition).

## Time and Space Complexity

In terms of **Time Complexity**, the algorithm depends on the *depth* (**d**) and *width* (**w**) of the folders, resulting in ***O(d·w)***.

As in terms of ***Space Complexity***, the structure requires ***O(n)***, where ***n*** is the number of files with the desired extension. The procedure takes up ***O(n)*** space even though our method does not use any data structure because the recursive procedure creates a Stack in memory that depends on the number of returns the function does and hence the number of files.
